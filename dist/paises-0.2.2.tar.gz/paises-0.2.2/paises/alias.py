from countries import Countries

ctrs = Countries()
ctrs.load_wb()

def get_alias(elements):
    aliases = []
    for c in elements:
        if elements.search(c):
            aliases += elements.search(c)   
        else:
            aliases.append(c)
        
    return aliases